<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '^V/gLR++!rEfz!Zo R-}i2)gFfZT!BzO;]sFJj`+KWU :s$uy3[n7I$-^Mn+psD_' );
define( 'SECURE_AUTH_KEY',   'c.$vk$G^N-rsM$ ;ZS-zkoy6>3{~0clB}ervc&/I0,miJ.Y{1sD?fr~+GH]JrPQY' );
define( 'LOGGED_IN_KEY',     'ucZ:-$O$|(#CgXfn!T3=ivf0teA=,1}0?llD1T^T_[9kiuy01CVf,H^Uf^JpSX3n' );
define( 'NONCE_KEY',         '5>3&SO;Z:GTl@H;n[Q`r}|mz2+wkM7 f_#PzEh!nSyo kG>R^+<wnWNYP.Xv{}K.' );
define( 'AUTH_SALT',         ';h i`olex_HoHC5O:hV4g)VG^Lj]]hh2!w&&yM-m*bSi=Fx(#rh)%_)|Pn!k&%5%' );
define( 'SECURE_AUTH_SALT',  ')rO3i[_XR0dsMgx=-J0-U)MRHS1?}5MPB_(5/|OPNq6I?NFlZnw?N@!%$op-$L<O' );
define( 'LOGGED_IN_SALT',    '*N&(brz[-eR(Ke}`z&bt=/g0HQ 3wF(i0WKrK>stkdbZv89?;}ukJ@+1&*=zj&H)' );
define( 'NONCE_SALT',        'q.dRh3OQtfg&UXhn!ZkkRb5(1W )wj5X=:d)#bTW]ldTWkJU]sGA2*K;wY)F!MGP' );
define( 'WP_CACHE_KEY_SALT', 'VpjYII6|g)a9l@jV:Apm&I*KU(=Uj_TfL-A>i_gLuruI0t?lM2gD[Xw#.EJ@d|V[' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
